/**
 * Internal dependencies
 */
import Block from './block';

export default Block;
