export const namespace = 'woocommerce-google-analytics';
export const actionPrefix = 'experimental__woocommerce_blocks';
