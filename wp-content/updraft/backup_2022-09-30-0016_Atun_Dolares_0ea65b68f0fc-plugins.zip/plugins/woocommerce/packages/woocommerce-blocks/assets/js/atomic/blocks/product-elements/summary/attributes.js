export const blockAttributes = {
	productId: {
		type: 'number',
		default: 0,
	},
};

export default blockAttributes;
