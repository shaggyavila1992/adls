// eslint-disable-next-line camelcase
declare let __webpack_public_path__: string;
