export { default as TotalsCoupon } from './coupon';
export { default as TotalsDiscount } from './discount';
export { default as TotalsFooterItem } from './footer-item';
export { default as TotalsShipping } from './shipping';
