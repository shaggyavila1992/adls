/* CUSTOM VARS START */
/* REAL_TABLE_NAME: `wp_wc_category_lookup`; */
/* PRE_TABLE_NAME: `1664496102_wp_wc_category_lookup`; */
/* CUSTOM VARS END */

CREATE TABLE IF NOT EXISTS `1664496102_wp_wc_category_lookup` ( `category_tree_id` bigint(20) unsigned NOT NULL, `category_id` bigint(20) unsigned NOT NULL, PRIMARY KEY (`category_tree_id`,`category_id`)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
INSERT INTO `1664496102_wp_wc_category_lookup` (`category_tree_id`, `category_id`) VALUES (37,37),(38,38),(39,39),(40,40),(41,41),(42,37),(42,38),(42,39),(42,40),(42,41),(42,42),(43,43),(43,44),(43,45),(43,46),(43,47),(43,48),(44,44),(45,45),(46,46),(47,47),(48,48);
