/* CUSTOM VARS START */
/* REAL_TABLE_NAME: `wp_jet_rel_default`; */
/* PRE_TABLE_NAME: `1664496102_wp_jet_rel_default`; */
/* CUSTOM VARS END */

CREATE TABLE IF NOT EXISTS `1664496102_wp_jet_rel_default` ( `_ID` bigint(20) NOT NULL AUTO_INCREMENT, `created` timestamp NULL DEFAULT current_timestamp(), `rel_id` text COLLATE utf8mb4_unicode_ci DEFAULT NULL, `parent_rel` int(11) DEFAULT NULL, `parent_object_id` bigint(20) DEFAULT NULL, `child_object_id` bigint(20) DEFAULT NULL, PRIMARY KEY (`_ID`)) ENGINE=InnoDB AUTO_INCREMENT=24 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
INSERT INTO `1664496102_wp_jet_rel_default` (`_ID`, `created`, `rel_id`, `parent_rel`, `parent_object_id`, `child_object_id`) VALUES (2,'2022-09-28 19:39:35',2,0,1346,379),(7,'2022-09-29 13:33:04',5,0,1322,744),(8,'2022-09-29 13:34:27',5,0,1276,744),(9,'2022-09-29 14:11:22',2,0,744,1322),(12,'2022-09-29 14:31:14',2,0,379,1322),(13,'2022-09-29 14:32:28',2,0,379,1276),(14,'2022-09-29 14:33:18',2,0,744,1324),(16,'2022-09-29 14:34:18',2,0,379,1324),(17,'2022-09-29 14:34:59',2,0,744,1276),(18,'2022-09-29 14:42:35',2,0,742,1346),(19,'2022-09-29 14:43:04',2,0,742,1276),(20,'2022-09-29 14:44:06',2,0,542,1322),(22,'2022-09-29 14:44:46',2,0,542,1324),(23,'2022-09-29 14:45:34',2,0,381,1322);
