/* CUSTOM VARS START */
/* REAL_TABLE_NAME: `wp_wpforms_tasks_meta`; */
/* PRE_TABLE_NAME: `1664496102_wp_wpforms_tasks_meta`; */
/* CUSTOM VARS END */

CREATE TABLE IF NOT EXISTS `1664496102_wp_wpforms_tasks_meta` ( `id` bigint(20) NOT NULL AUTO_INCREMENT, `action` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL, `data` longtext COLLATE utf8mb4_unicode_ci NOT NULL, `date` datetime NOT NULL, PRIMARY KEY (`id`)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
