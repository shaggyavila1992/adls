/* CUSTOM VARS START */
/* REAL_TABLE_NAME: `wp_woocommerce_shipping_zones`; */
/* PRE_TABLE_NAME: `1664496102_wp_woocommerce_shipping_zones`; */
/* CUSTOM VARS END */

CREATE TABLE IF NOT EXISTS `1664496102_wp_woocommerce_shipping_zones` ( `zone_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT, `zone_name` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL, `zone_order` bigint(20) unsigned NOT NULL, PRIMARY KEY (`zone_id`)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
